package com.apex.utility;

/**
 * Author: Adam
 * Created: 2/6/2018
 * Simple class with a main method for testing using the console.
 */
public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
