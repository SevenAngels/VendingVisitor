# VendingVisitor
Application which tracks the contents and attributes of various vending machines around the University of North Carolina at Charlotte campus.
